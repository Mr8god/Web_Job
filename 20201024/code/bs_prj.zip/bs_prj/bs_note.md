# BootStrap框架

下载:https://v3.bootcss.com

~~~html
bootstrap/
├── css/
│   ├── bootstrap.css         - ※ 开发dev环境引入的
│   ├── bootstrap.css.map
│   ├── bootstrap.min.css     - ※ 压缩,prod生产环境引入的
│   ├── bootstrap.min.css.map
│   ├── bootstrap-theme.css
│   ├── bootstrap-theme.css.map
│   ├── bootstrap-theme.min.css
│   └── bootstrap-theme.min.css.map
├── js/
│   ├── bootstrap.js        - ※
│   └── bootstrap.min.js    - ※
└── fonts/
    ├── glyphicons-halflings-regular.eot
    ├── glyphicons-halflings-regular.svg
    ├── glyphicons-halflings-regular.ttf
    ├── glyphicons-halflings-regular.woff
    └── glyphicons-halflings-regular.woff2
~~~



# 体验-骨架

~~~html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim 和 Respond.js 是为了让 IE8 支持 HTML5 元素和媒体查询（media queries）功能 -->
    <!-- 警告：通过 file:// 协议（就是直接将 html 页面拖拽到浏览器中）访问页面时 Respond.js 不起作用 -->
    <!--[if lt IE 9]>
      <script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <h1>你好，世界！</h1>

    <!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
  </body>
</html>
~~~

复制https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js到浏览器 - ctrl+a,cv大法复制到jquery.min.js文件



# 理解一下什么是UI框架

~~~html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../plugins/bootstrap-3.3.7-dist/css/bootstrap.css">
</head>
<body>

    <!-- bootstrap中提供的按钮样式 -->
    <button class="btn btn-danger">危险按钮</button>
    
    <!-- bootstrap框架是依赖于jquery框架,bootstrap.js文件中使用到了jquery语法,所以必须
    先引入jquery.js文件 -->
    <script src="../plugins/jquery/jquery.min.js"></script>
    <script src="../plugins/bootstrap-3.3.7-dist/js/bootstrap.js"></script>
</body>
</html>
~~~



# 教程

https://www.runoob.com/bootstrap/bootstrap-tutorial.html



# 作业

https://www.microsoft.com/zh-cn/



# 容器布局

* constainer
* container-fluid

~~~html
<!-- 左右两白 - 适配 -->
<div class="container" style="border: 1px solid #000;">
  <!-- 一行 -->
  <div class="row">
    <img src="../imgs/yy.png">
  </div>
</div>

<hr>

<div class="container-fluid">
  <div class="row">
    <img src="../imgs/yy.png">
  </div>
</div>
~~~



# 栅格系统-网格系统

* 一行永远只有12列
* 响应式 - 响应的是设备











